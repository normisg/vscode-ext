# Network Security Toolkit

A small container image bundling common network security and diagnostic tools, plus the GitLab CI pipeline to build it and a Helm chart to deploy it on Kubernetes.

## Contents

```
.
├── Dockerfile              # Alpine-based image with the tools
├── .gitlab-ci.yml          # Build & push to GitLab Container Registry
└── helm/
    └── netsec-toolkit/     # Helm chart (no ingress, no persistent storage)
```

## Tools included

`openssl`, `nmap` (+ scripts), `tcpdump`, `telnet` (via `busybox-extras`), `ping` (via `iputils`), `dig` (via `bind-tools`), `curl`, `wget`, `netcat`.

## 1. Push the code to a new GitLab repo

Create an empty project in GitLab (UI: *New project → Create blank project*, leave "Initialize repository with a README" unchecked), then:

```bash
git init
git remote add origin git@gitlab.com:<your-group>/<your-project>.git
git add .
git commit -m "Initial commit: netsec toolkit"
git push -u origin main
```

The pipeline runs automatically and pushes the image to `registry.gitlab.com/<your-group>/<your-project>`.

## 2. Build locally (optional)

```bash
docker build -t netsec-toolkit .
docker run --rm -it netsec-toolkit sh
```

## 3. Deploy with Helm

Update `helm/netsec-toolkit/values.yaml` with your registry path, then:

```bash
# If your registry is private, create a pull secret first:
kubectl create secret docker-registry gitlab-registry \
  --docker-server=registry.gitlab.com \
  --docker-username=<gitlab-user> \
  --docker-password=<personal-access-token-or-deploy-token> \
  -n default

helm install netsec ./helm/netsec-toolkit \
  --set image.repository=registry.gitlab.com/<your-group>/<your-project> \
  --set image.tag=latest \
  --set imagePullSecrets[0].name=gitlab-registry
```

Then exec into the pod:

```bash
kubectl exec -it deploy/netsec-netsec-toolkit -- sh
```

## Notes on capabilities

`tcpdump` and some `nmap` scan modes (e.g. `-sS` SYN scans) need raw sockets. The chart grants `NET_ADMIN` and `NET_RAW` capabilities by default. If your cluster has a restrictive PodSecurityPolicy / Pod Security Admission profile, you may need to relax the namespace label or trim these capabilities in `values.yaml`.
