export function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  const index = Math.floor(Math.log(bytes) / Math.log(1024));
  return (bytes / Math.pow(1024, index)).toFixed(2) + ' ' + units[index];
}

export function toBytes(
  value: number,
  unit: 'B' | 'KB' | 'MB' | 'GB' | 'TB',
): number {
  switch (unit) {
    case 'B':
      return value;
    case 'KB':
      return value * 1024;
    case 'MB':
      return value * 1024 ** 2;
    case 'GB':
      return value * 1024 ** 3;
    case 'TB':
      return value * 1024 ** 4;
  }
}
