import { Injectable } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import { TusService } from '../files/tus.service';

@Injectable()
export class TasksService {
  constructor(private readonly tusService: TusService) {}
  @Cron('0 0 * * * *') // every hour
  async cleanUpExpiredTusUploads() {
    await this.tusService.cleanUpExpiredUploads();
  }
}
