import { IsDate, IsString, IsNotEmpty } from 'class-validator';
import { Type } from 'class-transformer';
import { UploadCreateDto } from './upload-create.dto';
import { IsValidMimeTypeForExtension } from '../validators/is-valid-mime-type-for-extension.validator';

export class UploadFinishedDto extends UploadCreateDto {
  @Type(() => Date)
  @IsDate()
  created: Date;

  @IsString()
  @IsNotEmpty()
  @IsValidMimeTypeForExtension()
  path: string;
}
