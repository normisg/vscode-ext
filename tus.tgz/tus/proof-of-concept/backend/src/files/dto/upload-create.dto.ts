import { IsString, IsIn, IsNumber, IsNotEmpty, Min } from 'class-validator';
import { Category, CATEGORY_CONFIG } from '../config/categories.config';
import { FileExtension } from '../config/extensions.config';
import { IsValidExtensionForCategory } from '../validators/is-valid-extension-for-category.validator';
import { IsValidSizeForCategory } from '../validators/is-valid-size-for-category.validator';

export class UploadCreateDto {
  @IsString({ message: 'Invalid filename' })
  @IsNotEmpty({ message: 'Filename is required' })
  filename: string;

  @IsIn(Object.keys(CATEGORY_CONFIG), { message: 'Invalid category' })
  category: Category;

  @IsNumber({}, { message: 'File not found' })
  @Min(1, { message: 'File not found' })
  @IsValidSizeForCategory()
  size: number;

  @IsValidExtensionForCategory()
  extension: FileExtension;
}
