import { Category } from '../config/categories.config';
import { IsEnum, IsNotEmpty, IsNumber, Min } from 'class-validator';
import {
  FileScalarFieldEnum,
  SortOrder,
} from '../../generated/prisma/internal/prismaNamespace';
import { Type } from 'class-transformer';

export class FilesFindDto {
  @IsEnum(FileScalarFieldEnum)
  @IsNotEmpty()
  orderBy: FileScalarFieldEnum = FileScalarFieldEnum.createdAt;

  @IsEnum(SortOrder)
  @IsNotEmpty()
  orderDirection: SortOrder = SortOrder.desc;

  @IsEnum(Category)
  @IsNotEmpty()
  category: Category;

  @Type(() => Number)
  @IsNumber()
  @Min(1)
  limit: number = 10;

  @Type(() => Number)
  @IsNumber()
  @Min(1)
  page: number = 1;
}
