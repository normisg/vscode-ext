import { FileExtension } from './extensions.config';
import { toBytes } from '../../common/utils/units';

export enum Category {
  CoverLetters = 'cover_letters',
  Attachments = 'attachments',
  Video = 'video',
}

export const CATEGORY_CONFIG: Record<
  Category,
  {
    allowedExtensions: FileExtension[];
    maxFileSizeInBytes: number;
  }
> = {
  [Category.CoverLetters]: {
    allowedExtensions: [
      FileExtension.Pdf,
      FileExtension.Docx,
      FileExtension.Doc,
    ],
    maxFileSizeInBytes: toBytes(1, 'GB'),
  },
  [Category.Attachments]: {
    allowedExtensions: [FileExtension.Pdf, FileExtension.Jpg],
    maxFileSizeInBytes: toBytes(1, 'GB'),
  },
  [Category.Video]: {
    allowedExtensions: [
      FileExtension.Mp4,
      FileExtension.Avi,
      FileExtension.Mpeg,
    ],
    maxFileSizeInBytes: toBytes(1, 'GB'),
  },
} as const;
