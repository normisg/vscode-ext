export enum FileExtension {
  Pdf = 'pdf',
  Doc = 'doc',
  Docx = 'docx',
  Jpg = 'jpg',
  Mp4 = 'mp4',
  Avi = 'avi',
  Mpeg = 'mpeg',
}

export const EXTENSIONS_MIME_TYPES: Record<FileExtension, string[]> = {
  [FileExtension.Pdf]: ['application/pdf'],
  [FileExtension.Doc]: ['application/msword'],
  [FileExtension.Docx]: [
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  ],
  [FileExtension.Jpg]: ['image/jpeg'],
  [FileExtension.Mp4]: ['video/mp4'],
  [FileExtension.Avi]: ['video/avi'],
  [FileExtension.Mpeg]: ['video/mpeg'],
};
