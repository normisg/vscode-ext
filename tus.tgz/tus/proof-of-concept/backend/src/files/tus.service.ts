import { HttpException, Injectable, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { IncomingMessage, ServerResponse } from 'http';
import * as path from 'path';
import { plainToInstance } from 'class-transformer';
import { validateOrReject, ValidationError } from 'class-validator';
import { Server, Upload } from '@tus/server';
import { FileStore } from '@tus/file-store';
import { FilesService } from './files.service';
import { UploadCreateDto } from './dto/upload-create.dto';
import { UploadFinishedDto } from './dto/upload-finished.dto';

const ROUTE_PATH = '/files/upload';
const TUS_TEMP_DIR = '/storage/tmp';
const EXPIRATION_PERIOD = 24 * 60 * 60 * 1000; // 24 hours

interface TusHttpError {
  status_code: number;
  body: string;
}

@Injectable()
export class TusService implements OnModuleInit {
  private server: Server;
  constructor(
    private readonly fileService: FilesService,
    private readonly configService: ConfigService,
  ) {}

  onModuleInit() {
    this.initializeTusServer();
  }

  private initializeTusServer() {
    const frontendUrl = this.configService.get<string>('FRONTEND_URL') ?? '';

    this.server = new Server({
      path: ROUTE_PATH,
      datastore: new FileStore({
        directory: path.join(process.cwd(), TUS_TEMP_DIR),
        expirationPeriodInMilliseconds: EXPIRATION_PERIOD,
      }),
      allowedOrigins: [frontendUrl],
      onUploadCreate: async (req, upload) => {
        const uploadCreateDto = this.mapToUploadCreate(upload);
        await validateOrReject(uploadCreateDto);
        return Promise.resolve({});
      },
      onUploadFinish: async (req, upload) => {
        const uploadFinishedDto = this.mapToUploadFinished(upload);
        await validateOrReject(uploadFinishedDto);
        await this.fileService.handleUploadedFile(uploadFinishedDto);
        return Promise.resolve({});
      },
      onResponseError: (req, err) => {
        console.log(err);
        return Promise.resolve(this.mapToTusHttpError(err));
      },
    });
  }

  async handleUpload(req: IncomingMessage, res: ServerResponse): Promise<void> {
    return this.server.handle(req, res);
  }

  private mapToUploadCreate(upload: Upload): UploadCreateDto {
    const { metadata, size } = upload;
    const extension = path
      .extname(metadata?.filename ?? '')
      .toLowerCase()
      .replace(/^\./, '');
    const dto = plainToInstance(UploadCreateDto, {
      filename: metadata?.filename,
      category: metadata?.category,
      size,
      extension,
    });

    return dto;
  }

  private mapToUploadFinished(upload: Upload): UploadFinishedDto {
    const base = this.mapToUploadCreate(upload);
    const dto = plainToInstance(UploadFinishedDto, {
      ...base,
      created: upload?.creation_date,
      path: upload?.storage?.path,
    });

    return dto;
  }

  private mapToTusHttpError(error: unknown): TusHttpError {
    if (
      Array.isArray(error) &&
      error.every((e) => e instanceof ValidationError)
    ) {
      const messages: string[] = [];
      for (const err of error) {
        messages.push(...Object.values(err.constraints ?? {}));
      }

      return this.createTusHttpError(400, { message: messages });
    }

    if (error instanceof HttpException) {
      const status = error.getStatus();
      const response = error.getResponse();

      return this.createTusHttpError(
        status,
        typeof response === 'string' ? { message: [response] } : response,
      );
    }

    if (
      typeof error === 'object' &&
      error !== null &&
      'status_code' in error &&
      'body' in error &&
      typeof error.body === 'string'
    ) {
      return this.createTusHttpError(Number(error.status_code), {
        message: [error.body],
      });
    }

    if (error instanceof Error) {
      return this.createTusHttpError(500, { message: [error.message] });
    }

    return this.createTusHttpError(500, {});
  }

  createTusHttpError(status: number, body: object): TusHttpError {
    const _body: Record<string, unknown> = {
      message: ['Unknown error'],
      statusCode: status,
    };
    for (const [key, value] of Object.entries(body)) {
      _body[key] = value;
    }
    return {
      status_code: status,
      body: JSON.stringify(_body),
    };
  }

  async cleanUpExpiredUploads(): Promise<void> {
    await this.server.cleanUpExpiredUploads();
  }
}
