import {
  ValidatorConstraint,
  ValidatorConstraintInterface,
  ValidationArguments,
  registerDecorator,
  ValidationOptions,
} from 'class-validator';
import { CATEGORY_CONFIG } from '../config/categories.config';
import { UploadCreateDto } from '../dto/upload-create.dto';
import { formatBytes } from '../../common/utils/units';

@ValidatorConstraint({ name: 'isValidSizeForCategory', async: false })
export class IsValidSizeForCategoryConstraint implements ValidatorConstraintInterface {
  validate(size: number, args: ValidationArguments): boolean {
    const dto = args.object as UploadCreateDto;
    const category = dto.category;

    if (!category || !CATEGORY_CONFIG[category]) {
      return false;
    }

    const maxSize = CATEGORY_CONFIG[category].maxFileSizeInBytes;
    return size <= maxSize;
  }

  defaultMessage(args: ValidationArguments): string {
    const dto = args.object as UploadCreateDto;
    const category = dto.category;
    const maxSize = category
      ? (CATEGORY_CONFIG[category]?.maxFileSizeInBytes ?? 0)
      : 0;

    return `The selected file is too large(${formatBytes(dto.size)}). Maximum allowed size for this category is ${formatBytes(maxSize)}.`;
  }
}

export function IsValidSizeForCategory(validationOptions?: ValidationOptions) {
  return function (object: object, propertyName: string) {
    registerDecorator({
      target: object.constructor,
      propertyName: propertyName,
      options: validationOptions,
      constraints: [],
      validator: IsValidSizeForCategoryConstraint,
    });
  };
}
