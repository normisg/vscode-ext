import {
  ValidatorConstraint,
  ValidatorConstraintInterface,
  ValidationArguments,
  registerDecorator,
  ValidationOptions,
} from 'class-validator';
import { FileExtension } from '../config/extensions.config';
import { CATEGORY_CONFIG } from '../config/categories.config';
import { UploadCreateDto } from '../dto/upload-create.dto';

@ValidatorConstraint({ name: 'isValidExtensionForCategory', async: false })
export class IsValidExtensionForCategoryConstraint implements ValidatorConstraintInterface {
  validate(extension: FileExtension, args: ValidationArguments): boolean {
    const dto = args.object as UploadCreateDto;
    const category = dto.category;

    if (!category || !CATEGORY_CONFIG[category]) {
      return false;
    }

    const allowedExtensions = CATEGORY_CONFIG[category].allowedExtensions;
    return allowedExtensions.includes(extension);
  }

  defaultMessage(args: ValidationArguments): string {
    const dto = args.object as UploadCreateDto;
    const category = dto.category;
    const allowedExtensions = category
      ? (CATEGORY_CONFIG[category]?.allowedExtensions ?? [])
      : [];

    return `The selected file type is not allowed for this category. Allowed types are: ${allowedExtensions.join(', ')}`;
  }
}

export function IsValidExtensionForCategory(
  validationOptions?: ValidationOptions,
) {
  return function (object: object, propertyName: string) {
    registerDecorator({
      target: object.constructor,
      propertyName: propertyName,
      options: validationOptions,
      constraints: [],
      validator: IsValidExtensionForCategoryConstraint,
    });
  };
}
