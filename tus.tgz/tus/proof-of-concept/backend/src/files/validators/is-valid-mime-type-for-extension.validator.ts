import {
  ValidatorConstraint,
  ValidatorConstraintInterface,
  ValidationArguments,
  registerDecorator,
  ValidationOptions,
} from 'class-validator';
import { fileTypeFromFile } from 'file-type';
import { EXTENSIONS_MIME_TYPES } from '../config/extensions.config';
import { UploadCreateDto } from '../dto/upload-create.dto';

@ValidatorConstraint({ name: 'isValidMimeTypeForExtension', async: true })
export class IsValidMimeTypeForExtensionConstraint implements ValidatorConstraintInterface {
  async validate(path: string, args: ValidationArguments): Promise<boolean> {
    const dto = args.object as UploadCreateDto;

    const type = await fileTypeFromFile(path);
    const allowedMimeTypes = EXTENSIONS_MIME_TYPES[dto.extension] ?? [];

    return !!type?.mime && allowedMimeTypes.includes(type.mime);
  }

  defaultMessage(): string {
    return `The file type does not match its extension.`;
  }
}

export function IsValidMimeTypeForExtension(
  validationOptions?: ValidationOptions,
) {
  return function (object: object, propertyName: string) {
    registerDecorator({
      target: object.constructor,
      propertyName: propertyName,
      options: validationOptions,
      constraints: [],
      validator: IsValidMimeTypeForExtensionConstraint,
    });
  };
}
