import { Injectable } from '@nestjs/common';
import { UploadFinishedDto } from './dto/upload-finished.dto';
import { FilesFindDto } from './dto/files-find.dto';
import { PrismaService } from '../prisma/prisma.service';
import { File, FileCategory } from '../generated/prisma/client';
import { v4 as uuidv4 } from 'uuid';
import { PaginatedFiles } from './files.types';
import { mkdir, rename, unlink } from 'fs/promises';

@Injectable()
export class FilesService {
  constructor(private prisma: PrismaService) {}

  async handleUploadedFile(upload: UploadFinishedDto): Promise<void> {
    const id = uuidv4();
    const rootDir = process.cwd();

    const oldPath = upload.path;
    const categoryDir = rootDir + '/storage/' + upload.category;
    const newPath = categoryDir + '/' + id;

    await mkdir(categoryDir, { recursive: true });
    await rename(oldPath, newPath);
    await unlink(oldPath + '.json');

    await this.prisma.file.create({
      data: {
        id,
        filename: upload.filename,
        category: upload.category as FileCategory,
        size: upload.size,
      },
    });
  }

  async findMany(dto: FilesFindDto): Promise<PaginatedFiles> {
    const { category, limit, page, orderBy, orderDirection } = dto;
    const skip = (page - 1) * limit;
    const take = limit;

    const [total, files] = await Promise.all([
      this.prisma.file.count({ where: { category } }),
      this.prisma.file.findMany({
        where: { category },
        skip,
        take,
        orderBy: { [orderBy]: orderDirection },
      }),
    ]);

    return { total, page, limit, data: files };
  }
}
