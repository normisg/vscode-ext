import { File } from '../generated/prisma/client';
export interface PaginatedFiles {
  total: number;
  page: number;
  limit: number;
  data: File[];
}
