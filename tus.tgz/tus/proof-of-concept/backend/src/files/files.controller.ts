import {
  Controller,
  All,
  Get,
  Req,
  Res,
  ValidationPipe,
  Query,
} from '@nestjs/common';
import { TusService } from './tus.service';
import { FilesService } from './files.service';
import { IncomingMessage, ServerResponse } from 'http';
import { FilesFindDto } from './dto/files-find.dto';
import { PaginatedFiles } from './files.types';

@Controller('files')
export class FilesController {
  constructor(
    private readonly tusService: TusService,
    private readonly filesService: FilesService,
  ) {}

  @All('upload{*path}')
  async tusUpload(
    @Req() req: IncomingMessage,
    @Res() res: ServerResponse,
  ): Promise<void> {
    return this.tusService.handleUpload(req, res);
  }

  @Get()
  async findFiles(
    @Query(new ValidationPipe({ transform: true })) dto: FilesFindDto,
  ): Promise<PaginatedFiles> {
    return await this.filesService.findMany(dto);
  }
}
