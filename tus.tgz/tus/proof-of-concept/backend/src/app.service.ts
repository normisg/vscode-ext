import { Injectable } from '@nestjs/common';

@Injectable()
export class AppService {
  getHello(): string {
    return 'Hello World, I am a NestJS backend running on 127.0.0.1:3000!';
  }
}
