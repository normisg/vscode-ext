Start containers
```bash
docker compose build --no-cache
docker compose up -d
```

- Frontend (vue3): http://localhost:5173
- Backend (nestjs): http://localhost:3000


Stop containers
```bash
docker compose down --rmi all -v
```