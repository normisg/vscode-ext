import axios from 'axios'
import { type FilesFind } from '../types/files'

const BACKEND_URL = import.meta.env.VITE_BACKEND_URL

export const FilesService = {
  findFiles: async (params: FilesFind) => {
    const res = await axios.get(`${BACKEND_URL}/files`, { params })
    return res.data
  },
}
