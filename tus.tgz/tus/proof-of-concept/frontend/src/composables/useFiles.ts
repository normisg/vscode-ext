import { readonly, ref } from 'vue'
import { FilesService } from '../services/files.service'
import type { File, PaginatedFiles, Category, FilesFind } from '../types/files'
import { OrderBy, OrderDirection } from '../types/files'

export function useFiles(category: Category) {
  const LIMIT_STORAGE_KEY = 'files-page-limit'
  const files = ref<File[]>([])
  const total = ref<number>(0)
  const page = ref<number>(1)
  const limit = ref<number>(Number(localStorage.getItem(LIMIT_STORAGE_KEY)) || 20)
  const orderBy = ref<OrderBy>(OrderBy.CreatedAt)
  const orderDirection = ref<OrderDirection>(OrderDirection.Desc)
  const loading = ref(false)
  const error = ref<unknown | null>(null)

  const fetchFiles = async () => {
    loading.value = true
    error.value = null
    try {
      const params: FilesFind = {
        category,
        limit: limit.value,
        page: page.value,
        orderBy: orderBy.value,
        orderDirection: orderDirection.value,
      }
      const response = (await FilesService.findFiles(params)) as PaginatedFiles
      files.value = response.data
      total.value = response.total
      page.value = response.page
      limit.value = response.limit
    } catch (err) {
      console.error(err)
      error.value = 'An error occurred while fetching files'
    } finally {
      loading.value = false
    }
  }

  const setPage = (newPage: number) => {
    page.value = newPage
    fetchFiles()
  }

  const setLimit = (newLimit: number) => {
    limit.value = newLimit
    localStorage.setItem(LIMIT_STORAGE_KEY, newLimit.toString())
    page.value = 1
    fetchFiles()
  }

  const sort = (newOrderBy: OrderBy) => {
    if (orderBy.value === newOrderBy) {
      orderDirection.value =
        orderDirection.value === OrderDirection.Asc ? OrderDirection.Desc : OrderDirection.Asc
    } else {
      orderBy.value = newOrderBy
    }
    fetchFiles()
  }

  return {
    files: readonly(files),
    total: readonly(total),
    page: readonly(page),
    limit: readonly(limit),
    orderBy: readonly(orderBy),
    orderDirection: readonly(orderDirection),
    loading: readonly(loading),
    error: readonly(error),
    fetchFiles,
    sort,
    setPage,
    setLimit,
  }
}
