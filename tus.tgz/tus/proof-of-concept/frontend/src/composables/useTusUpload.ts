import { ref } from 'vue'
import * as tus from 'tus-js-client'
import { UploadStatus } from '../types/upload'
import type { UploadProgress } from '../types/upload'

const BACKEND_URL = import.meta.env.VITE_BACKEND_URL

interface Options {
  id: string
  metadata: Record<string, string>
}

enum ResumableState {
  NONE,
  EXISTS,
  VALID,
}

export function useTusUpload(file: File, options: Options) {
  const progress = ref<UploadProgress>({
    bytesUploaded: 0,
    bytesTotal: file.size,
    percentage: 0,
  })
  const status = ref<UploadStatus>(UploadStatus.INITIALIZING)
  const errorMessages = ref<string[] | null>(null)
  const resumableState = ref<ResumableState>(ResumableState.NONE)

  let upload: tus.Upload | null = null

  function initialize() {
    if (upload) {
      upload.abort()
      upload = null
    }

    const metadata = {
      filename: file.name,
      filetype: file.type,
      ...options.metadata,
    }

    upload = new tus.Upload(file, {
      endpoint: `${BACKEND_URL}/files/upload`,
      metadata,
      chunkSize: 1024 * 1024 * 5,
      removeFingerprintOnSuccess: true,
      fingerprint: function () {
        return Promise.resolve(options.id)
      },
      onUploadUrlAvailable() {
        if (resumableState.value === ResumableState.VALID) {
          upload?.abort()
          resumableState.value = ResumableState.NONE
          status.value = UploadStatus.REATTACHED
        } else {
          status.value = UploadStatus.UPLOADING
        }
      },
      onAfterResponse(req, res) {
        if (
          req.getMethod() === 'HEAD' &&
          resumableState.value === ResumableState.EXISTS &&
          res.getStatus() === 200
        ) {
          resumableState.value = ResumableState.VALID
        }
      },
      onProgress(bytesUploaded, bytesTotal) {
        let percentage = Math.round((bytesUploaded / bytesTotal) * 1000) / 10
        percentage = Math.min(percentage, 99.9)
        progress.value.percentage = percentage
        progress.value.bytesUploaded = bytesUploaded
        progress.value.bytesTotal = bytesTotal
        if (bytesUploaded === bytesTotal) {
          status.value = UploadStatus.FINALIZING
        }
      },
      onError(err) {
        let messages = [err.message]
        if (err instanceof tus.DetailedError && err.originalResponse) {
          const body = err.originalResponse.getBody()
          const response = JSON.parse(body)
          messages = response.message
        }

        errorMessages.value = messages ?? ['Unknown error']
        status.value = UploadStatus.ERROR
      },
      onSuccess() {
        status.value = UploadStatus.COMPLETED
        progress.value.percentage = 100
      },
    })
  }

  async function start() {
    if (status.value === UploadStatus.UPLOADING) {
      return
    }

    if (status.value === UploadStatus.INITIALIZING) {
      initialize()
      const previous = await upload!.findPreviousUploads()

      if (previous.length > 0 && previous[0]) {
        resumableState.value = ResumableState.EXISTS
        upload!.resumeFromPreviousUpload(previous[0])
      }
    }

    upload?.start()
  }

  function pause() {
    upload?.abort()
    status.value = UploadStatus.PAUSED
  }

  async function remove() {
    try {
      await upload?.abort(true)
    } catch {}
    status.value = UploadStatus.REMOVED
  }

  async function restart() {
    try {
      await upload?.abort(true)
    } catch {}
    start()
  }

  return {
    progress,
    status,
    errorMessages,
    start,
    pause,
    remove,
    restart,
  }
}
