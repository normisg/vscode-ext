<template>
  <div class="task">
    <h1>Task View (Direct Fetch)</h1>
    <p>Data from NestJS Backend:</p>
    
    <div v-if="isLoading">
      <p>Loading response...</p>
    </div>

    <div v-else-if="error">
      <p style="color: red;">Error fetching data: {{ error.message }}</p>
      <p>Check if the NestJS backend is running on http://localhost:3000 and CORS is configured.</p>
    </div>

    <div v-else-if="backendResponse">
      <p><strong>{{ backendResponse }}</strong></p>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue';

// 1. Define reactive variables with explicit TypeScript types
const backendResponse = ref<string>('');
const error = ref<Error | null>(null);
const isLoading = ref<boolean>(true);

// NOTE ON URL: We use localhost:[HOST_PORT] because the browser (where the Vue app runs)
// accesses the backend via the host machine's Docker port mapping (3000:3000).
const NESTJS_URL = 'http://127.0.0.1:3000';

// 2. Define the asynchronous fetching function
const fetchData = async () => {
  isLoading.value = true;
  error.value = null;

  try {
    const response = await fetch(NESTJS_URL);
    
    if (!response.ok) {
      // Throw an error with the response status
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    
    // Assuming the backend returns plain text ("Hello World...")
    // Use .text() for plain text responses
    const result: string = await response.text(); 
    backendResponse.value = result;
    
  } catch (err) {
    console.error('Fetch error:', err);
    // Cast the catch error to a proper Error object if possible
    if (err instanceof Error) {
        error.value = err;
    } else {
        error.value = new Error('An unknown fetch error occurred.');
    }
  } finally {
    isLoading.value = false;
  }
};

// 3. Trigger the fetch logic when the component is mounted
onMounted(fetchData);
</script>

<style scoped>
.task {
  padding: 20px;
  text-align: center;
}
</style>