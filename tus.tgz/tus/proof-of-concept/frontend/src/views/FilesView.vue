<script setup lang="ts">
import UploadList from '../components/UploadList.vue'
import CategoriesList from '../components/CategoriesList.vue'
import FilesList from '../components/FilesList.vue'
import { Category } from '../types/files'
import { ref } from 'vue'

const selectedCategory = ref<Category | null>(null)
</script>

<template>
  <main>
    <UploadList />
    <CategoriesList v-if="!selectedCategory" @category-selected="selectedCategory = $event" />
    <FilesList
      v-if="selectedCategory"
      :category="selectedCategory"
      @back="selectedCategory = null"
    />
  </main>
</template>
