export enum Category {
  CoverLetters = 'cover_letters',
  Attachments = 'attachments',
  Video = 'video',
}

export const CategoryLabels = {
  [Category.CoverLetters]: 'Pavadvēstules',
  [Category.Attachments]: 'Pielikumi',
  [Category.Video]: 'Video',
}

export interface File {
  id: string
  filename: string
  category: Category
  size: number
  createdAt: Date
}

export enum OrderBy {
  Filename = 'filename',
  CreatedAt = 'createdAt',
  Size = 'size',
}

export enum OrderDirection {
  Asc = 'asc',
  Desc = 'desc',
}

export interface FilesFind {
  category: Category
  limit: number
  page: number
  orderBy: OrderBy
  orderDirection: OrderDirection
}

export interface PaginatedFiles {
  total: number
  page: number
  limit: number
  data: File[]
}
