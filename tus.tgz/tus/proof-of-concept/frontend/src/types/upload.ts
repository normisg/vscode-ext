import { Category } from './files'

export interface UploadEntry {
  id: string
  file: File
  category: Category
}

export interface UploadProgress {
  bytesUploaded: number
  bytesTotal: number
  percentage: number
}

export enum UploadStatus {
  INITIALIZING = 'initializing',
  REATTACHED = 'reattached',
  UPLOADING = 'uploading',
  PAUSED = 'paused',
  FINALIZING = 'finalizing',
  COMPLETED = 'completed',
  REMOVED = 'removed',
  ERROR = 'error',
}
