<script setup lang="ts">
import { ref } from 'vue'
import { useUploadsStore } from '../stores/uploads'
import { Category } from '../types/files'

const uploadsStore = useUploadsStore()

const props = defineProps<{
  category: Category
}>()

const isDragging = ref(false)

function handleFiles(files: File[]) {
  if (files.length > 0) {
    uploadsStore.addFiles(files, props.category)
  }
}

function onFilesSelected(e: Event) {
  const input = e.target as HTMLInputElement
  const files = Array.from(input.files || [])
  handleFiles(files)
  input.value = ''
}

function onDragOver(e: DragEvent) {
  e.preventDefault()
  e.stopPropagation()
  isDragging.value = true
}

function onDragLeave(e: DragEvent) {
  e.preventDefault()
  e.stopPropagation()
  isDragging.value = false
}

function onDrop(e: DragEvent) {
  e.preventDefault()
  e.stopPropagation()
  isDragging.value = false

  const files = Array.from(e.dataTransfer?.files || [])
  handleFiles(files)
}
</script>

<template>
  <div
    class="file-drop-zone"
    :class="{ 'is-dragging': isDragging }"
    @dragover="onDragOver"
    @dragleave="onDragLeave"
    @drop="onDrop"
  >
    <input type="file" multiple @change="onFilesSelected" />
    <div class="drop-zone-content">
      <div class="drop-zone-text">
        <strong>Drag and drop files here</strong>
        <span>or click to browse</span>
      </div>
    </div>
  </div>
</template>

<style scoped>
.file-drop-zone {
  position: relative;
  border: 2px dashed #ddd;
  border-radius: 4px;
  padding: 3rem 2rem;
  text-align: center;
  cursor: pointer;
  background-color: #fafafa;
  transition: all 0.3s ease;
}

.file-drop-zone:hover {
  border-color: #42b883;
  background-color: #f0f9f6;
}

.file-drop-zone.is-dragging {
  border-color: #42b883;
  background-color: #e8f5f0;
  border-style: solid;
}

input[type='file'] {
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  opacity: 0;
  cursor: pointer;
  z-index: 1;
}

.drop-zone-content {
  position: relative;
  z-index: 0;
  pointer-events: none;
}

.drop-zone-text {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.drop-zone-text strong {
  font-size: 1.1rem;
  color: #333;
}

.drop-zone-text span {
  font-size: 0.9rem;
  color: #666;
}
</style>
