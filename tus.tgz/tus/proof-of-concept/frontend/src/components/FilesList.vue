<script setup lang="ts">
import { watch } from 'vue'
import { Category, CategoryLabels } from '../types/files'
import FileInput from './FileInput.vue'
import { useFiles } from '../composables/useFiles'
import { onMounted } from 'vue'
import { useUploadsStore } from '../stores/uploads'
import { formatBytes } from '../utils/units'
import { formatDate } from '../utils/date'
import { OrderBy, OrderDirection } from '../types/files'
import UiPagination from './ui/UiPagination.vue'
import UiButton from './ui/UiButton.vue'
import IconArrow from './icons/IconArrow.vue'

const props = defineProps<{
  category: Category
}>()

const emit = defineEmits<{
  (e: 'back'): void
}>()

const {
  files,
  total,
  page,
  limit,
  orderBy,
  orderDirection,
  loading,
  error,
  fetchFiles,
  sort,
  setPage,
  setLimit,
} = useFiles(props.category)

const uploadsStore = useUploadsStore()

watch(uploadsStore.completedUploads, (completedUploads) => {
  const lastUpload = completedUploads[completedUploads.length - 1]
  if (lastUpload?.category === props.category) {
    fetchFiles()
  }
})

onMounted(() => fetchFiles())

const listHeader = [
  { label: 'Name', ordering_key: OrderBy.Filename },
  { label: 'Created At', ordering_key: OrderBy.CreatedAt },
  { label: 'Size', ordering_key: OrderBy.Size },
]
</script>

<template>
  <div class="header">
    <h1>{{ CategoryLabels[category] }}</h1>
    <div class="header-buttons">
      <UiButton @click="emit('back')">
        <IconArrow style="vertical-align: text-bottom" direction="left" :size="15" />Back
      </UiButton>
      <UiButton @click="fetchFiles">Refresh</UiButton>
    </div>
  </div>
  <FileInput :category="category" />
  <div class="files-list-container">
    <div class="error" v-if="error">{{ error }}</div>
    <div class="files-list" v-if="!error">
      <UiPagination
        :total="total"
        :page="page"
        :limit="limit"
        @page-changed="setPage"
        @limit-changed="setLimit"
      />
      <div class="list-header">
        <div
          v-for="headerItem in listHeader"
          :key="headerItem.ordering_key"
          @click="sort(headerItem.ordering_key)"
        >
          {{ headerItem.label }}
          <IconArrow
            v-if="orderBy === headerItem.ordering_key"
            :direction="orderDirection === OrderDirection.Asc ? 'up' : 'down'"
            :size="16"
            color="rgb(0, 189, 126)"
          />
        </div>
      </div>
      <div class="list-items">
        <div class="loading" v-if="loading">Loading...</div>
        <div v-if="files.length > 0">
          <div class="list-item" v-for="file in files" :key="file.id">
            <div>{{ file.filename }}</div>
            <div>{{ formatDate(file.createdAt) }}</div>
            <div>{{ formatBytes(file.size) }}</div>
          </div>
        </div>
        <div v-else-if="!loading" class="no-files-found">No files found</div>
      </div>
      <UiPagination
        :total="total"
        :page="page"
        :limit="limit"
        @page-changed="setPage"
        @limit-changed="setLimit"
      />
    </div>
  </div>
</template>

<style scoped>
.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 1.25rem;
}

.files-list-container {
  margin-top: 1.25rem;
}

.error {
  margin: 0.5rem 0;
  background-color: #ffe5e5;
  padding: 0.25rem 0.5rem;
  border-radius: 4px;
  border: 1px solid #f5a5a5;
  color: #d32f2f;
  font-size: 0.75rem;
  font-weight: 600;
}

.loading {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(255, 255, 255, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.2rem;
  color: #000;
}

.files-list {
  margin: 20px 0 0;
}

.list-items {
  position: relative;
  min-height: 100px;
}

.list-header,
.list-item {
  display: grid;
  grid-template-columns: 1fr 200px 100px;
  align-items: center;
  width: 100%;
  border-bottom: 1px solid #ddd;
}

.list-header div,
.list-item div {
  padding: 10px;
}

.list-header div {
  display: flex;
  align-items: center;
  gap: 5px;
  font-weight: 600;
  cursor: pointer;
}

.list-item:first-child {
  border-top: 1px solid #ddd;
}

.list-item:nth-child(even) {
  background: #f5f5f5;
}

.list-item:nth-child(odd) {
  background: #fff;
}

.no-files-found {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100px;
  text-align: center;
  color: #666;
  font-size: 1rem;
}
</style>
