<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps<{
  direction: 'up' | 'down' | 'left' | 'right'
  size?: number
  color?: string
}>()

const size = props.size ?? 20
const color = props.color ?? 'currentColor'

const rotation = computed(() => {
  switch (props.direction) {
    case 'up':
      return -90
    case 'down':
      return 90
    case 'left':
      return 180
    case 'right':
    default:
      return 0
  }
})
</script>

<template>
  <i class="icon-arrow" :style="{ width: size + 'px', height: size + 'px' }">
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="100%"
      height="100%"
      viewBox="0 0 24 24"
      fill="none"
      :stroke="color"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
      :style="{ transform: `rotate(${rotation}deg)` }"
    >
      <line x1="5" y1="12" x2="19" y2="12" />
      <polyline points="12 5 19 12 12 19" />
    </svg>
  </i>
</template>
<style scoped>
i {
  display: inline-block;
  vertical-align: middle;
}
svg {
  display: block;
}
</style>
