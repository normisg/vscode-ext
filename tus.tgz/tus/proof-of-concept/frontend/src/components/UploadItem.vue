<script setup lang="ts">
import { ref, watch, onMounted, onUnmounted } from 'vue'
import { UploadStatus } from '../types/upload'
import { Category, CategoryLabels } from '../types/files'
import { useTusUpload } from '../composables/useTusUpload'
import UploadItemDialog from './UploadItemDialog.vue'
import { formatBytes } from '../utils/units'

const props = defineProps<{
  uploadId: string
  file: File
  category: Category
}>()

const emit = defineEmits<{
  (e: 'removed', id: string): void
  (e: 'completed', id: string): void
}>()

const actionsByStatus = {
  [UploadStatus.INITIALIZING]: ['remove'],
  [UploadStatus.REATTACHED]: ['start', 'remove'],
  [UploadStatus.UPLOADING]: ['pause', 'remove'],
  [UploadStatus.PAUSED]: ['start', 'remove'],
  [UploadStatus.FINALIZING]: [''],
  [UploadStatus.COMPLETED]: ['close'],
  [UploadStatus.REMOVED]: [''],
  [UploadStatus.ERROR]: ['remove'],
}

const needsResumeConfirmation = ref<boolean>(false)
const options = {
  id: props.uploadId,
  metadata: { category: props.category },
}

const { progress, status, errorMessages, start, pause, remove, restart } = useTusUpload(
  props.file,
  options,
)

watch(status, (s: UploadStatus) => {
  if (s === UploadStatus.REATTACHED) {
    needsResumeConfirmation.value = true
  }

  if (s === UploadStatus.REMOVED) {
    emit('removed', props.uploadId)
  }

  if (s === UploadStatus.COMPLETED) {
    emit('completed', props.uploadId)
  }
})

function handleDialogConfirm(value: boolean) {
  if (value) {
    start()
  } else {
    restart()
  }
  needsResumeConfirmation.value = false
}

onMounted(() => start())
onUnmounted(() => pause())
</script>

<template>
  <div class="upload">
    <strong>{{ CategoryLabels[category] }} / {{ file.name }}</strong>
    <div v-if="status !== UploadStatus.ERROR" class="bar">
      <div :style="{ width: progress.percentage + '%' }" />
      <span class="percentage">{{ progress.percentage }}%</span>
    </div>
    <div v-if="status === UploadStatus.ERROR">
      <div class="error" v-for="message in errorMessages" :key="message">
        {{ message }}
      </div>
    </div>

    <div class="actions-row">
      <div class="actions">
        <button v-if="actionsByStatus[status].includes('pause')" @click="pause">Pause</button>
        <button v-if="actionsByStatus[status].includes('start')" @click="start">Resume</button>
        <button v-if="actionsByStatus[status].includes('remove')" @click="remove">Remove</button>
        <button v-if="actionsByStatus[status].includes('close')" @click="emit('removed', uploadId)">
          Close
        </button>
      </div>
      <div class="progress">
        {{ formatBytes(progress.bytesUploaded) }} / {{ formatBytes(progress.bytesTotal) }}
      </div>
    </div>
    <UploadItemDialog
      v-if="needsResumeConfirmation"
      :message="'You already started uploading this file. Do you want to resume this upload?'"
      :yes-label="'YES, RESUME'"
      :no-label="'NO, START OVER'"
      @confirm="handleDialogConfirm"
    />
  </div>
</template>

<style scoped>
.upload {
  position: relative;
  padding: 1rem;
  margin: 1rem 0;
  border: 1px solid #ddd;
  border-radius: 4px;
  overflow: hidden;
}

.bar {
  position: relative;
  height: 24px;
  background: #eee;
  border-radius: 4px;
  border: 1px solid #42b883;
  margin: 0.5rem 0;
  overflow: hidden;
}

.bar > div {
  height: 100%;
  background: #42b883;
  transition: width 0.3s ease;
}

.percentage {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  font-size: 0.75rem;
  font-weight: 600;
  color: #333;
  z-index: 1;
}

.error {
  margin: 0.5rem 0;
  background-color: #ffe5e5; /* very light red/pinkish background */
  padding: 0.25rem 0.5rem;
  border-radius: 4px;
  border: 1px solid #f5a5a5; /* subtle red border */
  color: #d32f2f; /* darker but not harsh red for text */
  font-size: 0.75rem;
  line-height: 1rem;
  font-weight: 600;
}

.actions-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  min-height: 25px;
}

.actions {
  display: flex;
  gap: 0.5rem;
}

.actions button {
  padding: 0.25rem 0.75rem;
  border: 1px solid #ddd;
  border-radius: 4px;
  background: white;
  cursor: pointer;
}

.actions button:hover {
  background: #f5f5f5;
}

.progress {
  font-size: 0.75rem;
}
</style>
