<script setup lang="ts">
  const { message, yesLabel, noLabel } = defineProps<{
    message: string
    yesLabel?: string
    noLabel?: string
  }>()
  
  const emit = defineEmits<{
    (e: 'confirm', value: boolean): void
  }>()

</script>
  
<template>
  <div class="dialog-overlay">
    <div class="dialog-content">
      <p class="message">
        {{ message }}
      </p>
      <div class="dialog-actions">
        <button @click="emit('confirm', true)" class="btn-yes">
          {{ yesLabel || 'Yes' }}
        </button>
        <button @click="emit('confirm', false)" class="btn-no">
          {{ noLabel || 'No' }}
        </button>
      </div>
    </div>
  </div>
</template>

<style scoped>
.dialog-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: #fff;
  display: flex;
  z-index: 10;
  animation: fadeIn 0.2s ease;
}

.dialog-content {
  padding: 1.5rem;
  width: 100%;
}

.dialog-content .message {
  margin: 0 0 1rem 0;
  color: #000;
  font-size: 1rem;
  font-weight: 600;
}

.dialog-actions {
  display: flex;
  gap: 0.75rem;
  margin-top: 0;
}

.btn-yes,
.btn-no {
  padding: 0.5rem 1rem;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-weight: 600;
  font-size: 0.75rem;
  transition: all 0.2s ease;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.btn-yes {
  background: #42b883;
  color: white;
}

.btn-yes:hover {
  background: #359268;
}

.btn-no {
  background: white;
  color: #666;
  border: 1px solid #ddd;
}

.btn-no:hover {
  background: #f9f9f9;
  border-color: #ccc;
}

@keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
</style>
  