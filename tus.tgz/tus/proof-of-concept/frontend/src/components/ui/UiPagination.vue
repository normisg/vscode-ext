<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import IconArrow from '../icons/IconArrow.vue'

const props = defineProps({
  total: { type: Number, required: true },
  page: { type: Number, required: true },
  limit: { type: Number, required: true },
})

const emit = defineEmits<{
  (e: 'page-changed', page: number): void
  (e: 'limit-changed', limit: number): void
}>()

const localPage = ref<string>(String(props.page))
const localLimit = ref<number>(props.limit)

watch(
  () => props.page,
  (newPage) => {
    localPage.value = String(newPage)
  },
)

watch(
  () => props.limit,
  (newLimit) => {
    localLimit.value = newLimit
  },
)

const totalPages = computed(() => Math.max(1, Math.ceil(props.total / props.limit)))

function handlePageInput(event: Event) {
  const input = event.target as HTMLInputElement
  const value = input.value

  if (value === '') {
    localPage.value = ''
    return
  }

  const numericValue = value.replace(/\D/g, '')
  localPage.value = numericValue
}

function handlePageChange() {
  const pageNumber = parseInt(localPage.value, 10)

  if (isNaN(pageNumber) || localPage.value === '') {
    localPage.value = String(props.page)
    return
  }

  goToPage(pageNumber)
}

function goToPage(page: number) {
  const p = Math.max(1, Math.min(page, totalPages.value))
  localPage.value = String(p)
  emit('page-changed', p)
}

function handleLimitChange() {
  emit('limit-changed', localLimit.value)
}
</script>

<template>
  <div class="pagination">
    <select v-model.number="localLimit" @change="handleLimitChange">
      <option value="5">5</option>
      <option value="10">10</option>
      <option value="20">20</option>
      <option value="50">50</option>
      <option value="100">100</option>
    </select>
    <button @click="goToPage(page - 1)" :disabled="page === 1">
      <IconArrow direction="left" :size="14" />
    </button>
    <input
      type="text"
      inputmode="numeric"
      v-model="localPage"
      @input="handlePageInput"
      @change="handlePageChange"
    />
    <span>of {{ totalPages }}</span>
    <button @click="goToPage(page + 1)" :disabled="page === totalPages">
      <IconArrow direction="right" :size="14" />
    </button>
  </div>
</template>

<style scoped>
.pagination {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  gap: 10px;
  margin-top: 20px;
}

.pagination button {
  padding: 0.125rem 0.5rem;
  border: 1px solid #ddd;
  border-radius: 3px;
  background: white;
  color: rgb(0, 189, 126);
  cursor: pointer;
  font-size: 0;
}

.pagination button:disabled {
  color: #ddd;
}

.pagination button:hover:not(:disabled) {
  background: #f5f5f5;
}

.pagination select,
.pagination input {
  padding: 0.125rem;
  border: 1px solid #ddd;
  border-radius: 3px;
  background: white;
  cursor: pointer;
  font-size: 0.75rem;
}

.pagination input {
  width: 2.5rem;
  text-align: center;
}
</style>
