<script setup lang="ts">
defineProps<{
  disabled?: boolean
}>()
</script>

<template>
  <button :disabled="disabled">
    <slot />
  </button>
</template>

<style scoped>
button {
  margin-left: 10px;
  padding: 0.5rem 1rem;
  border: 1px solid #ddd;
  border-radius: 4px;
  background: white;
  cursor: pointer;
}

.header-buttons button:hover {
  background: #f5f5f5;
}
</style>
