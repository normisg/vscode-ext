<script setup lang="ts">
import TusUploadItem from './UploadItem.vue'
import { useUploadsStore } from '../stores/uploads'

const uploadsStore = useUploadsStore()
</script>

<template>
  <TusUploadItem
    v-for="u in uploadsStore.uploads"
    :key="u.id"
    :upload-id="u.id"
    :file="u.file"
    :category="u.category"
    @removed="uploadsStore.removeUpload"
    @completed="uploadsStore.registerCompletedUpload"
  />
</template>
