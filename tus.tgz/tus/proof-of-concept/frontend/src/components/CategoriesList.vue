<script setup lang="ts">
import { Category, CategoryLabels } from '../types/files'
import IconArrow from './icons/IconArrow.vue'

const emit = defineEmits<{
  (e: 'category-selected', category: Category): void
}>()
</script>

<template>
  <div class="header">
    <h1>Categories</h1>
  </div>
  <div class="categories-list">
    <div class="category-item" v-for="category in Object.values(Category)" :key="category">
      <button @click="emit('category-selected', category)">
        {{ CategoryLabels[category] }}
        <IconArrow direction="right" :size="16" color="rgb(0, 189, 126)" />
      </button>
    </div>
  </div>
</template>

<style scoped>
.categories-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin: 20px 0 0;
}

.category-item {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.category-item button {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 1rem;
  font-weight: 400;
  cursor: pointer;
  background: none;
  color: #000;
  text-align: left;
}

.category-item button:hover {
  background: #f5f5f5;
}
</style>
