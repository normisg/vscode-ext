import { ref } from 'vue'
import { defineStore } from 'pinia'
import type { UploadEntry } from '../types/upload'
import { Category } from '../types/files'

export const useUploadsStore = defineStore('uploads', () => {
  const uploads = ref<UploadEntry[]>([])
  const completedUploads = ref<UploadEntry[]>([])

  function addFiles(files: File[], category: Category) {
    for (const file of files) {
      const id = generateUploadId(file, category)
      if (uploads.value.some((u) => u.id === id)) {
        continue
      }
      uploads.value.push({
        id,
        file,
        category,
      })
    }
  }

  function generateUploadId(file: File, category: Category): string {
    return `${file.size}-${file.name}-${file.type}-${category}`
  }

  function removeUpload(id: string) {
    uploads.value = uploads.value.filter((u) => u.id !== id)
  }

  function registerCompletedUpload(id: string) {
    const upload = uploads.value.find((u) => u.id === id)
    if (upload) {
      completedUploads.value.push(upload)
    }
  }

  return { uploads, completedUploads, addFiles, removeUpload, registerCompletedUpload }
})
