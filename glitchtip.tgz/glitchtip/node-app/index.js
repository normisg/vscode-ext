const os = require("os");
const express = require("express");
const Sentry = require("@sentry/node");

const app = express();
const port = process.env.PORT || 3000;

// GlitchTip uses the same client protocol as Sentry, so the
// standard @sentry/node SDK works out of the box — just point
// it at your GlitchTip project's DSN.
if (process.env.GLITCHTIP_DSN) {
  if (process.env.GLITCHTIP_DSN.includes("localhost") || process.env.GLITCHTIP_DSN.includes("127.0.0.1")) {
    console.warn(
      "WARNING: GLITCHTIP_DSN points to 'localhost', which won't resolve to the " +
      "glitchtip container from inside node-app. Replace the host in the DSN with " +
      "the Docker service name 'glitchtip' (e.g. http://key@glitchtip:8000/1)."
    );
  }
  // Sentry.init({
  //   dsn: process.env.GLITCHTIP_DSN,
  //   tracesSampleRate: 0,
  //   includeLocalVariables: true,
  //   maxBreadcrumbs: 0,
  //   debug: true,
  // });

  Sentry.init({
    dsn: process.env.GLITCHTIP_DSN,
 
    // --- identification ---
    environment: process.env.NODE_ENV || "development",
    release: process.env.RELEASE || undefined, // e.g. a git SHA or package version, set via env
    serverName: process.env.SERVER_NAME || os.hostname(),
 
    // --- send as much detail as possible ---
    sendDefaultPii: true,       // include IP addresses, cookies, headers on events/requests
    attachStacktrace: true,     // attach a stack trace even to plain captureMessage() calls
    includeLocalVariables: true, // capture local variable values at each stack frame
    maxBreadcrumbs: 200,        // default is 100; keep a longer trail of prior events
    normalizeDepth: 10,         // default is 3; walk nested objects/context deeper before truncating
    maxValueLength: 5000,       // default is 250; allow longer strings (e.g. large payloads) through
 
    // --- performance tracing ---
    tracesSampleRate: 1.0,      // capture 100% of transactions (dial down in real production use)
 
    integrations: [
      // Traces outgoing HTTP requests made from this app as spans/breadcrumbs
      new Sentry.Integrations.Http({ tracing: true }),
      // Captures local variable values in stack frames for thrown exceptions
      new Sentry.Integrations.LocalVariables({ captureAllExceptions: true }),
      // Records console.log/warn/error calls as breadcrumbs leading up to an event
      new Sentry.Integrations.Console(),
    ],
 
    // Uncomment to redact specific fields before anything leaves this process,
    // while keeping everything else at maximum detail:
    // beforeSend(event) {
    //   if (event.request?.headers) {
    //     delete event.request.headers.authorization;
    //     delete event.request.headers.cookie;
    //   }
    //   return event;
    // },
  });

  app.use(Sentry.Handlers.requestHandler());
}

app.get("/", (req, res) => {
  res.send("Node app is up. Try /error to send a test event to GlitchTip.");
});

// Hit this route to confirm errors show up in GlitchTip
app.get("/error", (req, res) => {
  throw new Error("Test error sent to GlitchTip");
});

if (process.env.GLITCHTIP_DSN) {
  app.use(Sentry.Handlers.errorHandler());
}

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).send("Something broke — check GlitchTip for the report.");
});

app.listen(port, () => {
  console.log(`Node app listening on port ${port}`);
});