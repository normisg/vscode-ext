
#!/usr/bin/env bash
# Minimal Ubuntu 24.04 baseline + root ssh key access
# Args: NODE_HOSTNAME NODE_IP ROOT_PUBKEY
set -ex

NODE_HOSTNAME="${1:-}"
NODE_IP="${2:-}"
ROOT_PUBKEY="${3:-}"

export DEBIAN_FRONTEND=noninteractive

# Set /etc/hosts entries for convenience
if ! grep -q "$NODE_HOSTNAME" /etc/hosts; then
  echo "$NODE_IP $NODE_HOSTNAME" >> /etc/hosts
fi

# Configure SSH: enable root login with key, disable password login
mkdir -p /root/.ssh
chmod 700 /root/.ssh
echo "$ROOT_PUBKEY" > /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys

# Harden SSH a bit: no password, key-only for root, disable challenge-response
SSHD="/etc/ssh/sshd_config"
cp -f "$SSHD" "${SSHD}.bak"

# Ensure these directives exist / overwrite if present
sed -ri 's/^\s*PermitRootLogin\s+.*/PermitRootLogin prohibit-password/' "$SSHD" \
  || echo "PermitRootLogin prohibit-password" >> "$SSHD"
sed -ri 's/^\s*PasswordAuthentication\s+.*/PasswordAuthentication no/' "$SSHD" \
  || echo "PasswordAuthentication no" >> "$SSHD"
sed -ri 's/^\s*ChallengeResponseAuthentication\s+.*/ChallengeResponseAuthentication no/' "$SSHD" \
  || echo "ChallengeResponseAuthentication no" >> "$SSHD"
sed -ri 's/^\s*UsePAM\s+.*/UsePAM yes/' "$SSHD" \
  || echo "UsePAM yes" >> "$SSHD"

systemctl restart ssh || systemctl restart sshd || true

echo "[$(date '+%F %T')] ${NODE_HOSTNAME} ready; root key installed; SSH hardened."
