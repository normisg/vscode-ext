https://docs.rke2.io/install/quickstart
https://medium.com/@jdegbun/deploying-a-kubernetes-cluster-with-rke2-on-virtual-machines-f152ecb51c9f
https://tech-couch.com/post/automating-rke2-kubernetes-installation-with-ansible
https://metallb.io/installation/

https://oneuptime.com/blog/post/2026-02-20-metallb-rke2-install/view
https://github.com/Chris-Greaves/metallb-ansible/blob/main/README.md

----------------------

vagrant up

vagrant status

vagrant snapshot save clean


# custom docker
helm, kubectl, ansible, ansible-playbook


cd ansible

ansible -i inventory.yaml -m ping all

ansible-playbook -i inventory.yaml 01_validate.yaml

ansible-playbook -i inventory.yaml 02_prepare_nodes.yaml

vagrant snapshot save nodes_prepared

ansible-playbook -i inventory.yaml 03_setup_cluster.yaml

vagrant snapshot save cluster_prepared


# MetalLb

kubectl apply -f https://raw.githubusercontent.com/metallb/metallb/v0.15.3/config/manifests/metallb-native.yaml

https://github.com/Chris-Greaves/metallb-ansible/blob/main/README.md
