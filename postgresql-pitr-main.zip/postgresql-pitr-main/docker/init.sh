#!/bin/sh
cd "$(dirname "$0")"
mkdir -p data backup/base backup/wal
chmod 0777 -R data backup