#!/bin/bash
# Dzēš backupus, kas vecāki par N dienām
#
# Pielietojam:
#   ./scripts/cleanup.sh           # uses default (7 days)
#   ./scripts/cleanup.sh 14        # keep last 14 days
#
# Būtu jālaiž *pēc* backup veikšanas
# basebackup and WAL tiek glabāts vienādu laiku

set -e
cd "$(dirname "$0")"

RETAIN_DAYS="${1:-7}"
CUTOFF=$(date -d "-${RETAIN_DAYS} days" '+%Y-%m-%d')

echo "Retention: ${RETAIN_DAYS} days (cutoff: ${CUTOFF})"
echo ""

# Compare directory name (YYYY-MM-DD) against the cutoff date.
# Lexicographic comparison works correctly for this date format.
echo "Base backups removed:"
found=0
for dir in ./backup/base/*/; do
  [ -d "$dir" ] || continue
  name=$(basename "$dir")
  if [[ "$name" < "$CUTOFF" ]]; then
    echo "  $name"
    rm -rf "$dir"
    found=1
  fi
done
[ "$found" -eq 0 ] && echo "  (none)"

# WAL files are created by archive_command at archival time, so mtime is reliable.
echo "WAL files removed:"
deleted=$(find ./backup/wal -type f -mtime "+${RETAIN_DAYS}" -print -delete)
if [ -z "$deleted" ]; then
  echo "  (none)"
else
  echo "$deleted" | sed 's/^/  /'
fi

echo ""
echo "Remaining base backups:"
ls -1 ./backup/base/ 2>/dev/null || echo "  (none)"
