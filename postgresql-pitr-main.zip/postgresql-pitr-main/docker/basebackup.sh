#!/bin/bash
# Backupi glabājas ./backup/base/YYYY-MM-DD/
# palaižot vēlreiz, backups overraido dienas backupu


set -e
cd "$(dirname "$0")"

DATE=$(TZ='Europe/Riga' date '+%Y-%m-%d')
BACKUP_DIR="/var/lib/postgresql/basebackup/$DATE"

echo "Taking base backup for $DATE..."

# Dzēša, lai varētu pa tīro uztaisīt vēlreiz, ja folderis eksistē.
docker compose run --rm --no-deps \
  --entrypoint sh postgres -c "rm -rf '$BACKUP_DIR'"

# pg_basebackup connects via the local Unix socket
# -D  : destination directory inside the container
# -Fp : plain format (directory copy)
# -Xs : stream WAL during backup so the backup is self-consistent
# -P  : show progress
docker compose exec postgres pg_basebackup \
  -D "$BACKUP_DIR" \
  -Fp -Xs -P \
  -U postgres

echo ""
echo "Bāzes backups galā: $BACKUP_DIR"
echo "Laiks: $(TZ='Europe/Riga' date '+%Y-%m-%d %H:%M:%S') Europe/Riga"
