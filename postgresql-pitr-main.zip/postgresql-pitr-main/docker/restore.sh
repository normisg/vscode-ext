#!/bin/bash
# Restaurē bāzi uz noteiktu laiku (PITR).
#
# Lietošana:
#   ./scripts/restore.sh "YYYY-MM-DD HH:MM:SS"
#
# Kas notiek:
#   1. Flushes the active WAL segment to the archive
#   2. Stops the postgres container
#   3. Finds the most recent base backup and restores it to the data directory
#   4. Writes recovery settings (target time + promote action)
#   5. Creates recovery.signal so PostgreSQL enters recovery mode
#   6. Restarts postgres — it replays archived WAL up to the target time,
#      then promotes to a normal read/write instance

set -e
cd "$(dirname "$0")"

TARGET_TIME="$1"

if [ -z "$TARGET_TIME" ]; then
  echo "Usage: $0 \"YYYY-MM-DD HH:MM:SS\""
  exit 1
fi

echo "==> Flushing current WAL segment to archive..."
# PostgreSQL only archives completed WAL segments. The active segment is still
# in pg_wal and would be lost when we replace the data dir. pg_switch_wal()
# forces a segment switch, ensuring the latest WAL is archived before we stop.
docker compose exec postgres psql -U postgres -c "SELECT pg_switch_wal();" -t
sleep 2   # Give archive_command time to copy the segment

echo "==> Stopping postgres..."
docker compose stop postgres

echo "==> Finding most recent base backup..."
# Base backups are stored as dated directories: /var/lib/postgresql/basebackup/YYYY-MM-DD/
# Pick the latest one (sort is lexicographic; YYYY-MM-DD format sorts correctly).
LATEST_BACKUP=$(docker compose run --rm --no-deps \
  --entrypoint sh postgres -c "ls -1d /var/lib/postgresql/basebackup/*/  2>/dev/null | sort | tail -1 | tr -d '\n'")

if [ -z "$LATEST_BACKUP" ]; then
  echo "ERROR: No base backup found in /var/lib/postgresql/basebackup/"
  echo "Run ./scripts/basebackup.sh first."
  exit 1
fi

echo "Using base backup: $LATEST_BACKUP"

echo "==> Restoring data directory from base backup..."
docker compose run --rm --no-deps \
  --entrypoint sh postgres -c "
    rm -rf /var/lib/postgresql/data
    cp -rp '$LATEST_BACKUP' /var/lib/postgresql/data
    echo 'Data directory restored.'
  "

echo "==> Configuring recovery target: $TARGET_TIME"
docker compose run --rm --no-deps \
  --entrypoint sh postgres -c "
    echo \"recovery_target_time = '$TARGET_TIME'\" >> /var/lib/postgresql/data/postgresql.auto.conf
    echo \"recovery_target_action = 'promote'\"    >> /var/lib/postgresql/data/postgresql.auto.conf
    touch /var/lib/postgresql/data/recovery.signal
    echo 'Recovery settings written.'
  "

echo "==> Starting postgres in recovery mode..."
docker compose start postgres

echo ""
echo "Recovery started. PostgreSQL will replay WAL up to: $TARGET_TIME"
echo "Monitor progress:  docker compose logs -f postgres"
echo "Connect and verify: psql -h localhost -U postgres"
