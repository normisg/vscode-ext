#!/bin/sh
kubectl delete -f deployment.yaml -f cronjob.yaml -f backup-scripts-configmap.yaml
sudo rm -rf backup data