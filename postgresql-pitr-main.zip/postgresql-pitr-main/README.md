# PostgreSQL PITR Projekta Dokumentācija

**Īsumā:** Tas ir mācību/demo projekts (PoC), kas parāda, kā PostgreSQL iebūvētos dublēšanas mehānismus (base backup + WAL arhivēšana) var saslēgt kopā datu atjaunošanai gan vienkāršā Docker vidē, gan produkcijai pietuvinātā Kubernetes vidē.

## Galvenā problēma, ko šis risina
Ja dati tiek nejauši izdzēsti, sabojāti vai cieš no neveiksmīgas migrācijas, PITR ļauj atgriezties tieši tajā brīdī, kas bija pirms incidenta, nevis zaudēt visu informāciju, kas uzkrāta kopš pēdējās pilnās dublēšanas.

## Kā tas strādā
1. **Bāzes dublējumi (*Base backups*)** – periodiski pilni PostgreSQL datu direktorija uzņēmumi, izmantojot `pg_basebackup`, saglabāti datētiem nosaukumiem (GGGG-MM-DD).
2. **WAL arhivēšana** – PostgreSQL nepārtraukti arhivē *Write-Ahead Log* segmentus (katru datubāzē veikto izmaiņu) atsevišķā vietā.
3. **Atjaunošana** – kad nepieciešams, tiek atjaunots jaunākais bāzes dublējums, konfigurācijā norādīts mērķa laika zīmogs, un PostgreSQL "atspēlē" arhivētos WAL segmentus līdz noteiktajam brīdim.

## Divas varianti (docker un kubernetes testiem)

| Parametrs | Docker Compose (`/docker/`) | Kubernetes (`/k8/`) |
| :--- | :--- | :--- |
| **Mērķis** | Lokālā izstrāde / mācības | Produkcijas tipa iestatījums |
| **Dublējumi** | Manuāla `basebackup.sh` izpilde | *CronJob* pēc grafika |
| **Atjaunošana** | `restore.sh` skripts | `restore.sh` mērogo deployment uz 0, palaiž restore pod, mērogo atpakaļ |
| **Glabāšana** | Lokālais *volume mounts* | *PersistentVolume* (hostPath) |


## Docker varianta demo

```bash
# Ieejam docker mapē
cd docker

# Varam laist pirmajā reizē droši lai patīrītu visu veco. Bet arī tad, kad gribam vēlreiz visu iedarbināt.
./reset_all.sh

# Uztaisam mapes (./backup/base ./backup/wal) ar permīcijām
./init.sh

# Paceļam percona for postgresql
docker compose up -d

# Pagaidām drusku lai db ieskrienas
sleep 5

# Insertjam datus tabulā
docker compose exec postgres psql -c "CREATE TABLE employees (id serial PRIMARY KEY, name text); INSERT INTO employees (name) VALUES ('Alice'), ('Bob'); SELECT * FROM employees"

# Uztaisam pilno backup ar pg_basebackup
./basebackup.sh

# Nedaudz nogaidām 
sleep 2

# Izvadam uz ekrāna laiku, uz kuru gribēsim atgriezties 
# (idejiski jebkurš laiks, bet testam setojam stāvokli ar diviem tabulas ierakstiem)
RESTORE=$(TZ='Europe/Riga' date '+%Y-%m-%d %H:%M:%S'); echo $RESTORE

# Izdzēšam vienu ierakstu, parādam kā izskatās tabula
docker compose exec postgres psql -c "DELETE FROM employees WHERE id = 1; SELECT * FROM employees"

# Atgriežamies uz iepriekš setoto laiku
./restore.sh "$RESTORE"
sleep 3

# Kā izskatās tabula pēc restore (vajadzētu būt diviem ierakstiem)
docker compose exec postgres psql -c "SELECT * FROM employees"

# Tīram vecos ierakstus (folderus vecākus par N dienām)
./cleanup.sh 7
```


## Kubernetes varianta demo

Pieņemu, ka ir strādājošs k8 klasteris, komanda `kubectl` strādā. 

```bash
# Dodamies mapē
cd k8

# Sākam svaigi (dzēš deploymentus, backupus)
./reset_all.sh


# !! Modificējam cronjob.yaml, ierakstot laiku, kad tiek taisīti pilnie backupi !!
# Produkcijā varētu būt '0 0 * * *', testiem var uzlikt +~1 min no esošā laika

# Deployojam resursus
kubectl apply -f deployment.yaml -f cronjob.yaml -f backup-scripts-configmap.yaml
sleep 7

# Testa pēc insērtojam datus, paskatamies vai tiek atgriezti
kubectl exec -it $(kubectl get pod -l app=postgres -o name) -- psql -U postgres -c "CREATE TABLE employees (id serial PRIMARY KEY, name text); INSERT INTO employees (name) VALUES ('Alice'), ('Bob'); SELECT * FROM employees"

# Pagaidām, kad nostrādā crons (pods postgres-backup... ar statusu Completed), pēc tam:

# Fiksējam laiku, ko gribēsim patīt atpakaļ
RESTORE=$(TZ='Europe/Riga' date '+%Y-%m-%d %H:%M:%S'); echo $RESTORE

# Dzēšam datus, parādam kas paliek pāri
kubectl exec -it $(kubectl get pod -l app=postgres -o name) -- psql -U postgres -c "DELETE FROM employees WHERE id = 1; SELECT * FROM employees"

# Atjaunojam datubāzi līdz $RESTORE laikam
./restore.sh "$RESTORE"

# Pārbaudām, vai dati ir atgriezušies
kubectl exec -it $(kubectl get pod -l app=postgres -o name) -- psql -U postgres -c "SELECT * FROM employees"
```